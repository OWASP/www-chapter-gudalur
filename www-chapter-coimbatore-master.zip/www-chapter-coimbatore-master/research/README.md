## OWASP Coimbatore Research Repository

**Contributions :**

- Any one can contribute their research in Application and Information Security and to OWASP Coimbatore.
- If you feel that your research is unique and of great help to the Infosec Community, then feel free to `Fork` this repository, Upload your Research in [research](research) directory
- Rise a `Pull Request` after uploading your Research.
- If the Research is Unique, the Pull Request will be merged within 24-72 Hours.

