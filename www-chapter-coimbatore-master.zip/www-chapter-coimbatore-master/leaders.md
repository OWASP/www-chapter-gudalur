### Leaders

* [Adithyan Ak](mailto:adithyan.ak@owasp.org)
* [Naveen Kumar](mailto:naveen.kumar@owasp.org)

### Board Members

* [Vignesh C (Secretary)](mailto:vignesh4303@gmail.com)
* [Kabilan S (Conference Coordinator)](mailto:kabilansakthivel1290@gmail.Com)
* [Gowtham G (Academic Coordinator)](mailto:noobtechie126@gmail.com)
* [Raghul M  (CTF and Workshop Coordinator)](mailto:hello@raghul.ml)

### Leader Contact

- [Linkedin](https://in.linkedin.com/in/akinfosec)
- [Facebook](https://www.facebook.com/akinfosec)
- [Twitter](https://twitter.com/adithyan_ak)
- [Instagram](https://www.instagram.com/adithyan.ak)
- [Github](https://github.com/adithyan-ak)
