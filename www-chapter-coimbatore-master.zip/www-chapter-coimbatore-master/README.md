<h1 align="center">OWASP Coimbatore Chapter</h1>

<h5 align="center">
  <br>
  <a href="https://github.com/OWASP/www-chapter-coimbatore"><img src="assets/images/logo/owasp_coimbatore_logo.jpg" alt="OWASP Coimbatore"></a>
</h5>

This is the source repository of OWASP Coimbatore. The Chapter wiki is located at https://owasp.org/www-chapter-coimbatore

**Contributions**

- Any one can contribute their research in Application and Information Security and to OWASP Coimbatore.
- If you feel that your research is unique and of great help to the Infosec Community, then feel free to `Fork` this repository, Upload your Research in [research](research) directory
- Rise a `Pull Request` after uploading your Research.
- If the Research is Unique, the Pull Request will be merged within 24-72 Hours.
