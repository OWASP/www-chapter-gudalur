### Tweets

<div class="center">
<blockquote class="twitter-tweet"><p lang="en" dir="ltr">Here are the slides of the <a href="https://twitter.com/hashtag/OWASP_Coimbatore?src=hash&amp;ref_src=twsrc%5Etfw">#OWASP_Coimbatore</a>&#39;s webinar on <a href="https://twitter.com/hashtag/Reconnaissance?src=hash&amp;ref_src=twsrc%5Etfw">#Reconnaissance</a> by Mr. vignesh Chandrasekaran (<a href="https://twitter.com/bbinfosec?ref_src=twsrc%5Etfw">@bbinfosec</a>) Chief Security Officer at Precise Thinking TCT.<a href="https://twitter.com/owasp?ref_src=twsrc%5Etfw">@owasp</a> <a href="https://twitter.com/OWASPBangalore?ref_src=twsrc%5Etfw">@OWASPBangalore</a> <a href="https://twitter.com/OWASPLondon?ref_src=twsrc%5Etfw">@OWASPLondon</a> <a href="https://twitter.com/OWASPdelhi?ref_src=twsrc%5Etfw">@OWASPdelhi</a> <a href="https://t.co/bhN59aj0Lo">https://t.co/bhN59aj0Lo</a></p>&mdash; OWASP Coimbatore (@OwaspCBE) <a href="https://twitter.com/OwaspCBE/status/1257523703857831937?ref_src=twsrc%5Etfw">May 5, 2020</a></blockquote> 

</div>

### Social Handles

* [Meetup](https://www.meetup.com/owasp-coimbatore-meetup-group/)
* [Twitter](https://twitter.com/OwaspCBE?lang=en)
* [Linkedin](https://www.linkedin.com/company/owasp-coimbatore)
* [Instagram](https://www.instagram.com/owaspcoimbatore/)
* [Facebook](https://www.facebook.com/owaspcoimbatore/)
* [Slack](https://join.slack.com/t/owaspcoimbatore/shared_invite/zt-dzjz7u5t-4Nab~nJKCn7cHkTKY_wu7A)
* [Telegram](https://t.me/joinchat/AAAAAEf26WPpZcPe7B3mRw)
* [Discord](https://discord.gg/N9QUA2K)

### Code Repository
* [GitHub](https://github.com/OWASP/www-chapter-coimbatore)

### Meetup Handle
* [Meetup](https://www.meetup.com/owasp-coimbatore-meetup-group)

### Change Log
* [changes](https://github.com/OWASP/www-chapter-coimbatore/commits/master)
