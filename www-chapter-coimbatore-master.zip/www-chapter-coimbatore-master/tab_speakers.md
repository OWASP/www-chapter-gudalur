---
title: speakers
displaytext: Speakers
layout: null
tab: true
order: 3
tags: Coimbatore OWASP Chapter India

---
## Speakers
<img src="assets/images/logo/Speaker_banner.jpeg"/>


Would you like to speak on the upcoming OWASP Coimbatore Webinar? [Contact Us](mailto:adithyanak@owasp.org)

**Email Format :**

- Speaker name
- Job Role
- Company / Organization
- Country
- Email ID
- Contact Number
- Speaker Profile
- Presentation Details
    - Name / Title of the Presentation
    - Abstract of the presentation
    - Presentation time required
